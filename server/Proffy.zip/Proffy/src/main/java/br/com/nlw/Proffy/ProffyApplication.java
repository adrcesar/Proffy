package br.com.nlw.Proffy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProffyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProffyApplication.class, args);
	}

}
