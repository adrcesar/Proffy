package br.com.nlw.Proffy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProffyApplicationTests {

	@Test
	void contextLoads() {
	}

}
